__author__ = 'periap'

import requests
session = requests.Session()
print("In the Sample ViPR API project")
#Login Request
loginResponse = session.get("https://10.247.42.58:4443/login", auth=("root", "ChangeMe1!"), verify=False)
print(loginResponse)
#
token = loginResponse.headers['x-sds-auth-token']

#Logout Request
logoutResponse = session.get("https://10.247.42.58:4443/logout", verify=False, headers={'x-sds-auth-token': token, 'Accept': 'application/json'})
print(logoutResponse)



