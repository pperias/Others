#!/usr/bin/python
import json
from ViPRConnection import ViPRConnection
from SNHelper import SNHelper


import logging
import sys
import time

class ViPRCatalogServiceCLI(object):
    def __init__(self):
        FORMAT = "%(levelname)s:%(module)s:%(relativeCreated)dms:%(message)s"
        logging.basicConfig(filename='myapp.log', format=FORMAT, level=logging.DEBUG)
        logging.info("This script helps to create snapshots of a volume in ViPR")
        
        self.snHelper = SNHelper()
        # arguments = self.snHelper.parseArgumentsForCreateBlockSnapShot()
        arguments = []
        self.viprConnection = ViPRConnection()
        self.config = self.snHelper.readFile("config.json")
        self.main()

    """
        main function parses the arguments passed in the input and facilitates the Snapshot retention for the block volume passed
        myargs - input which are viphost - VIPT host, username - VIP username, password - VIP password and volume - block volume name
    """

    def readFile(self, fileName):
        try:
            fileHandle = open(self.getFileLocation(fileName), 'r')
            readFile_raw = fileHandle.read()
            logging.debug(fileName + ":\n" + readFile_raw)
            fileContentsList = json.loads(readFile_raw)
        except IOError:
            logging.error("Error: can\'t find file " + fileName + " or read data")
        else:
            fileHandle.close()
            return fileContentsList

    def main(self):
        dcList = self.config['viprs']
        i =1

        dcDict = {}

        for eachItem in dcList:
            for dc_key, dc_value in eachItem.items():
                pass
            print(str(i) + ". " + dc_key)
            dcDict[i] = dc_value
            i = i + 1


        print("Enter which DC you would like to do provisioning")
        answer = sys.stdin.readline()
        answer = answer.strip()

        viphost = dcDict[int(answer)]["host"]
        username = dcDict[int(answer)]["username"]
        password = dcDict[int(answer)]["password"]
        logging.info("ViPR Host is = " + viphost)
        # logging.info("Username = " + username)
        # logging.info("Password = " + password)

        # Get Token
        token = self.viprConnection.login(viphost, username, password)

        #Get Tenant
        # For the demo go with provider tenant
        get_tenant_req = self.config['get_tenant']
        getTenant_response_jsontxt = self.viprConnection.get_request(viphost, token, get_tenant_req)
        tenantId = getTenant_response_jsontxt["id"]


        #Get the categories offered in the ViPR
        get_categories_req = self.config['get_categories']
        getCategories_response_jsontxt = self.viprConnection.get_request(viphost, token, get_categories_req)
        #print(getCategories_response_jsontxt)
        serviceCatalogId = getCategories_response_jsontxt["id"]

        #GET Catalog sub-category id
        get_catalog_sub_category_req = self.config['get_catalog_sub_category']
        get_catalog_sub_category_req = get_catalog_sub_category_req.replace("{id}", serviceCatalogId)
        getCatalogSubCategory_response_jsontxt = self.viprConnection.get_request(viphost, token, get_catalog_sub_category_req)
        #print(getCatalogSubCategory_response_jsontxt)
        if(len(getCatalogSubCategory_response_jsontxt) > 0):
            catalogCategoryList = getCatalogSubCategory_response_jsontxt["catalog_category"]
            print("The catalog offerings in this ViPR are:")
            i = 1
            catalogSubCategoryDict = {}
            for eachCatalogCategory in catalogCategoryList:
                catalogCategoryName = eachCatalogCategory["name"]
                catalogCategoryId = eachCatalogCategory["id"]
                catalogSubCategoryDict[i] = {"id":catalogCategoryId,"name":catalogCategoryName}
                print(str(i) + ". " + catalogCategoryName)
                i = i + 1

            print("Pick a number from the above offerings")
            answer=sys.stdin.readline()
            answer = answer.strip()
            # if(answer.isdigit()):
            #     print(catalogSubCategoryDict[int(answer)])

            catalog_category_id = catalogSubCategoryDict[int(answer)]

            # GET Catalog Service ID
            get_catalog_services_req = self.config['get_catalog_serviceis_id']
            get_catalog_services_req = get_catalog_services_req.replace("{id}", catalog_category_id["id"])
            getCatalogServices_response_jsontxt = self.viprConnection.get_request(viphost, token, get_catalog_services_req)
            #print(getCatalogServices_response_jsontxt)
            if(len(getCatalogServices_response_jsontxt) > 0):
                catalogServicesList = getCatalogServices_response_jsontxt["catalog_service"]
                print("The catalog service offerings in this ViPR for "+ catalog_category_id["name"] + " are:")
                i = 1
                catalogServicesDict = {}
                for eachCatalogService in catalogServicesList:
                    catalogServiceName = eachCatalogService["name"]
                    catalogServiceId = eachCatalogService["id"]
                    catalogServicesDict[i] = {"id":catalogServiceId,"name":catalogServiceName}
                    print(str(i) + ". " + catalogServiceName)
                    i = i + 1

                print("Pick a number from the above Services")
                answer=sys.stdin.readline()
                answer = answer.strip()
                # if(answer.isdigit()):
                #     print(catalogServicesDict[int(answer)])

                catalog_service_str = catalogServicesDict[int(answer)]
                catalog_service_id = catalog_service_str["id"]

                catalog_service_name = catalog_service_str["name"]


        print("Building the request for the choosen catalog service "+ catalog_service_name)


        # test_serviceCategory = "Create Block Volume"
        # get service descriptor GET /catalog/service-descriptors
        get_catalog_service_descriptors_req = self.config['get_catalog_service_descriptors']
        get_catalog_service_descriptors_response_jsontxt = self.viprConnection.get_request(viphost, token, get_catalog_service_descriptors_req)

        # test_serviceCategory = "Create Block Volume"
        # test_serviceCategory = "Create Block Volume for a Host"
        #
        # put the serviceCategory here

        if(catalog_service_name == "CreateBlockVolumeforaHost"):
            test_serviceCategory = "Create Block Volume for a Host"
        elif(catalog_service_name == "CreateBlockVolume"):
            test_serviceCategory = "Create Block Volume"
        elif(catalog_service_name == "RemoveBlockVolumes"):
            test_serviceCategory = "Remove Block Volumes"
        elif(catalog_service_name == "ExpandBlockVolume"):
            test_serviceCategory = "Expand Block Volume"



        catalogServicesDescriptorList = get_catalog_service_descriptors_response_jsontxt["service_descriptor"]
        for eachCatalogServiceDescr in catalogServicesDescriptorList:
            if(eachCatalogServiceDescr["title"] == test_serviceCategory):
                #print(eachCatalogServiceDescr)
                targetCatalogServiceDescr = eachCatalogServiceDescr
                break

        items = targetCatalogServiceDescr["items"]
        #get the dependency list for this category
        dependencyList = []

        referenceDict = {}
        for eachItem in targetCatalogServiceDescr["items"]:
            myKey = eachItem.keys()
            if('field' in eachItem.keys()):
                if(eachItem['field']['asset']):
                    dependencyList.append(eachItem['field']['assetType'])
                if('initial_value' in eachItem['field'].keys()):
                    referenceDict[eachItem['field']['assetType']] = eachItem['field']['initial_value']
            elif('group' in eachItem.keys()):
                for eachGroupItem in eachItem['group']["items"]:
                    if('field' in eachGroupItem.keys()):
                        if(eachGroupItem['field']['asset']):
                            dependencyList.append(eachGroupItem['field']['assetType'])



        #get the dependency list
        finalRequest = {}
        get_dependencyList_payload_str = {}

        for eachItem in targetCatalogServiceDescr["items"]:
            get_dependencyList_req = self.config['getdependency_list']
            if('field' in eachItem.keys()):
                if(eachItem['field']['asset']):
                    get_dependencyList_req = get_dependencyList_req.replace("{assetType}", eachItem['field']['assetType'])

                    get_dependencyList_payload_str["availableAssetTypes"] = dependencyList
                    get_dependencyList_payload_str["tenantId"] = tenantId

                    get_dependencyListresponse_jsontxt = self.viprConnection.post_request_json(viphost, token,
                                                                                            get_dependencyList_req, get_dependencyList_payload_str)
                    result = get_dependencyListresponse_jsontxt["assetDependencies"]

                    makeRequest_payload = {}
                    makeRequest = self.config['assetRequest']
                    makeRequest = makeRequest.replace("{assetType}", eachItem['field']['assetType'])

                    makeRequest_payload["tenantId"] = tenantId
                    if not result:
                        pass
                    else:
                        #add dependency
                        availableAssetsDict = {}
                        for eachAssetDep in result:
                            if(test_serviceCategory == "Remove Block Volumes"):
                                referenceDict["vipr.deletionType"] = "FULL"

                            if(eachAssetDep in referenceDict):

                                availableAssetsDict[eachAssetDep] = referenceDict[eachAssetDep]
                        makeRequest_payload["availableAssets"] = availableAssetsDict


                    makeResponse_jsontxt = self.viprConnection.post_request_json(viphost, token,
                                                                                            makeRequest, makeRequest_payload)
                    returnDict = self.snHelper.printValues(makeResponse_jsontxt, "options", "The options available are as follows.", "key", "value")

                    if(returnDict):
                        referenceDict[eachItem['field']['assetType']] = returnDict["id"]
                        finalRequest[eachItem['field']['name']] = returnDict["id"]
                    else:
                        if(eachItem['field']['required']):
                            print( eachItem['field']['assetType'] + " is required. But it is returned empty with the above choosen values. Please verify.")
                            exit(0)



                else:
                    if(eachItem['field']['type'] == "text" ):
                        print(eachItem['field']['description'])
                    elif(not eachItem['field']['assetType']):
                        print(eachItem['field']['label'])
                    answer=sys.stdin.readline()
                    answer = answer.strip()
                    finalRequest[eachItem['field']['name']] = answer







        buildFinalRequest = {}
        buildFinalRequest["tenantId"] = tenantId
        buildFinalRequest["catalog_service"] = catalog_service_id
        buildFinalRequest["parameters"] = []
        tempDict={}
        for eachItem in finalRequest:
            tempDict={}
            tempDict["label"] = eachItem
            tempDict["value"] = finalRequest[eachItem]
            buildFinalRequest["parameters"].append(tempDict)


        # print(buildFinalRequest)
        print('\n\n\nDo you want to place the order with the above selected values... Press Y to continue... Any other key to quit: ')
        answer=sys.stdin.readline()

        if(answer.strip().upper()  == 'Y'):

            print('Placing the order..')
            time.sleep(2)



            buildFinalRequestPayload_str = buildFinalRequest

            postCatalogOrder_req = self.config['postCatalogOrder']

            postCatalogOrderResponse_jsontxt = self.viprConnection.post_request_json(viphost, token, postCatalogOrder_req, buildFinalRequestPayload_str)

            #print(postCatalogOrderResponse_jsontxt)

            print('Order is placed successfully..')
        else:
            print('Quiting without placing the order..')


        # Logout Request
        logout_jsontext = self.viprConnection.logout(viphost, token)


if __name__ == "__main__":
    ViPRCatalogServiceCLI()
