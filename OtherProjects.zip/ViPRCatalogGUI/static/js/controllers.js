/**
 * Created by delats on 11/17/2015.
 */
(function() {
    var viprAPP = angular.module('viprAPP', ['ngRoute']);

    viprAPP.controller('datacenterCLR', ['$scope', '$http', '$timeout', function($scope, $http, $timeout) {
        $scope.priority = [{
                "name": "Datacenter - New York",
                "index": 1,
                "host": "10.10.10.10",
                "username": "root",
                "password": "ChangeMe1!"
            },

            {
                "name": "Datacenter - Boston",
                "index": 2,
                "host": "10.10.10.10",
                "username": "root",
                "password": "ChangeMe1!"
            },

            {
                "name": "Datacenter - Paris",
                "index": 3,
                "host": "10.10.10.10",
                "username": "root",
                "password": "ChangeMe1!"
            }
        ];

        //This function will be calledd ViPR host is chose
        $scope.changed = function() {
            console.log($scope.selectedVipr);

            //var esto = $http.post('/dc/',JSON.stringify($scope.selectedVipr ))
            //console.log(esto)
            var xhr = $.ajax({
                type: "POST",
                url: "/dc/",
                headers: {
                    "accept": "text/json",
                    "charset": "utf-8",
                    "Content-Type": "application/json",
                },
                data: JSON.stringify($scope.selectedVipr),
                datatype: "json"
            }).success(function(data) {
                //                $scope.cancel()
                //console.log(data);

                $scope.CatalogChanged()
            });
        };
        //This function will be called Catalog is called
        $scope.CatalogChanged = function() {
            console.log($scope.selectedCS);
            var xhrs = $.ajax({
                type: "GET",
                url: "/viprdata/",
                headers: {
                    "accept": "text/json",
                    "charset": "utf-8",
                    "Content-Type": "application/json",
                },
                //data: JSON.stringify($scope.selectedCS),
                datatype: "json"
            }).success(function(data) {


                var dataParsed = JSON.parse(data);

                $scope.cs = JSON.parse(dataParsed["catalogService"]);

                $.each($scope.cs, function() {
                    console.log(this.num + "-" + this.title);
                    $("#catalogSRVC").append($('<option/>').text(this.title).val(this.num));
                    $("#catalogSRVC").selectpicker('refresh')
                });

                $scope.va = JSON.parse(dataParsed["varray"]);
                $.each($scope.va, function() {
                    console.log(this.num + "-" + this.title);
                    $("#vArray").append($('<option/>').text(this.title).val(this.num));
                    $('.selectpicker').selectpicker('refresh');
                    $("#vArray").prop('disabled', false);
                });
                $scope.vaChanged()

                $scope.vp = JSON.parse(dataParsed["vpool"]);
                $.each($scope.vp, function() {
                    console.log(this.num + "-" + this.title);
                    $("#vPool").append($('<option/>').text(this.title).val(this.num));
                    $('.selectpicker').selectpicker('refresh');
                    $("#vPool").prop('disabled', false);
                });
                $scope.vpChanged()

                $scope.pr = JSON.parse(dataParsed["project"]);
                $.each($scope.pr, function() {
                    console.log(this.num + "-" + this.title);
                    $("#project").append($('<option/>').text(this.title).val(this.num));
                    $('.selectpicker').selectpicker('refresh');
                    $("#project").prop('disabled', false);
                });
                $scope.pChanged()


            });
        };

        $scope.vaChanged = function() {
            console.log($scope.selectedVA);
        };

        $scope.vpChanged = function() {
            console.log($scope.selectedVP);
        };

        $scope.pChanged = function() {
            console.log($scope.selecteP);
        };



        $scope.submit = function() {
            console.log("submit");
            var xfiles = $.ajax({
                type: "POST",
                url: "/submitOrder/",
                headers: {
                    "accept": "text/json",
                    "charset": "utf-8",
                    "Content-Type": "application/json",
                },
                data: JSON.stringify({
                                    "catalog":$scope.catalogService,
                                    "virtualArray": $scope.virtualArray,
                                    "virtualPool": $scope.virtualPool,
                                    "project": $scope.project,
                                    "name":  $('#name').val(),
                                    "numVols":$('#numVols').val(),
                                    "size": $('#size').val()
                                            }),
                datatype: "json"
            }).success(function(data) {
                //console.log((data));
                //$scope.pr = JSON.parse(data);
                //$.each($scope.pr, function() {
                //
                //});

            });
        };


         $('#catalogSRVC').on('change', function(){
            $scope.catalogService = $(this).find("option:selected")[0]['value'];
          });
        $('#vArray').on('change', function(){
           $scope.virtualArray = $(this).find("option:selected")[0]['value'];
          });
        $('#vPool').on('change', function(){
            $scope.virtualPool = $(this).find("option:selected")[0]['value'];
          });

        $('#project').on('change', function(){
            $scope.project = $(this).find("option:selected").attr("value");
            var selected = $(this).find("option:selected").attr("value");
            console.log("proj"+selected)
            if(selected !== 0){
               $.ajax( $('#textBoxes').show());
            }
          });




        //This function will be called when
        //cancel button is pressed
        $scope.cancel = function() {
            console.log("cancel");
            $("#catalogSRVC").empty();
            $("#vArray").empty();
            $("#vPool").empty();
            $("#project").empty();
            $("#catalogSRVC").append($('<option/>').text("Select One").val(0))
            $("#vArray").append($('<option/>').text("Select One").val(0))
            $("#vPool").append($('<option/>').text("Select One").val(0))
            $("#project").append($('<option/>').text("Select One").val(0))
            $('.selectpicker').selectpicker('refresh');
        };


    }]);
})();