#!/usr/bin/python

import json
from ViPRConnection import ViPRConnection
from SNHelper import SNHelper
import cherrypy
import os

import logging
import sys
import time

__author__ = 'ViPR Soln dev'

localDir = os.path.dirname(__file__)
absDir = os.path.join(os.getcwd(), localDir)
viprConnection = ViPRConnection()
snHelper = SNHelper()
config = SNHelper().readFile("config.json")
catalogServicesDict = {}
finalRequest = {}
viphost = ""
username = ""
password = ""
token = ""
tenantId = ""

server_path = os.path.abspath(os.getcwd())


def getValues(writeFilename, config_key, viphost, token, root_tag, desc, changeValue):
    get_varrays_req = config[config_key]
    if (changeValue):
        get_varrays_req = get_varrays_req.replace("{id}", changeValue)
    response_jsontxt = viprConnection.get_request(viphost, token, get_varrays_req)
    SNHelper().writeJasonDataToFile(response_jsontxt, writeFilename)
    return getValues2(response_jsontxt, root_tag, desc)


def getValues2(response_jsontxt, root_tag, desc):
    print("problem")
    print(response_jsontxt)
    varraysList = response_jsontxt[root_tag]

    varraysDict = {}
    temp = []
    i = 0
    for eachvarray in varraysList:
        varraysDict[i] = eachvarray
        print(str(i) + ". " + eachvarray["name"])
        temp.append({"num": i, "title": eachvarray["name"]})
        i = i + 1
    return varraysDict, temp

"""
This class is for authentication to the datacenter that is choosen in the dropdown. after authentication, the token is persisted for further vipr api calls.
"""

class DataCenters(object):
    @cherrypy.expose()
    def index(self):
        request = cherrypy.request
        if request.method == 'POST':
            cl = cherrypy.request.headers['Content-Length']
            rawbody = cherrypy.request.body.read(int(cl)).decode("utf-8")
            ans = ((json.loads(rawbody)))

            cherrypy.session['index'] = ans['index']
            cherrypy.session['host'] = ans['host']
            cherrypy.session['username'] = ans["username"]
            cherrypy.session['password'] = ans["password"]

            # Get Token
            cherrypy.session['token'] = viprConnection.login(cherrypy.session['host'], cherrypy.session['username'],
                                                             cherrypy.session['password'])


            # Get Tenant
            # For the demo go with provider tenant
            get_tenant_req = config['get_tenant']
            getTenant_response_jsontxt = viprConnection.get_request(cherrypy.session['host'], cherrypy.session['token'],
                                                                    get_tenant_req)
            cherrypy.session['tenantId'] = getTenant_response_jsontxt["id"]

            # print(tenantId)
            return "Sucessfully authenticated"

"""
This class is for getting the data from ViPR such as the catalog service items,
virtual array, virtual pool, project etc.,


"""



class GetViprData(object):
    @cherrypy.expose()
    def index(self):
        request = cherrypy.request
        if request.method == 'GET':

            viprData = {}

            # get service descriptor GET /catalog/service-descriptors
            """
            caching was done by writing to a file. There are numerous other ways to do caching
            """
            get_catalog_service_descriptors_filename = config['cache_directory'] + "/" + config[
                'catalog_service_descriptors_fn'] + snHelper.replaceSpecialCharacters(cherrypy.session['host'])
            if (snHelper.checkIfFileExisits(get_catalog_service_descriptors_filename)):
                get_catalog_service_descriptors_response_jsontxt = snHelper.readFile(
                    get_catalog_service_descriptors_filename)
            else:
                """
                Get the catalog service descriptors.
                """
                get_catalog_service_descriptors_req = config['get_catalog_service_descriptors']
                get_catalog_service_descriptors_response_jsontxt = viprConnection.get_request(cherrypy.session['host'],
                                                                                              cherrypy.session['token'],
                                                                                              get_catalog_service_descriptors_req)


                snHelper.writeJasonDataToFile(get_catalog_service_descriptors_response_jsontxt,
                                              get_catalog_service_descriptors_filename)

            catalogServicesDescriptorList = get_catalog_service_descriptors_response_jsontxt["service_descriptor"]
            cherrypy.session['catalogServicesDict'] = {}
            i = 0
            catalogService = []
            for eachCatalogServiceDescr in catalogServicesDescriptorList:
                cherrypy.session['catalogServicesDict'][i] = eachCatalogServiceDescr
                print(str(i) + ". " + eachCatalogServiceDescr["title"])
                catalogService.append({"num": i, "title": eachCatalogServiceDescr["title"]})
                i = i + 1

            # return json.dumps(catalogService)
            json_catalogService_str = json.dumps(catalogService)
            viprData["catalogService"] = json_catalogService_str

            """
                Get the varrays
            """
            get_varrays_filename = config['cache_directory'] + "/" + config[
                'varrays_fn'] + snHelper.replaceSpecialCharacters(cherrypy.session['host'])

            if (snHelper.checkIfFileExisits(get_varrays_filename)):
                get_response_jsontxt = snHelper.readFile(get_varrays_filename)

                finalRequest["virtualArray"], getArray = getValues2(get_response_jsontxt, "varray", "")
                # finalRequest["virtualArray"] = getValues2(get_response_jsontxt,"varray","")
            else:

                finalRequest["virtualArray"], getArray = getValues(get_varrays_filename, 'get_varrays',
                                                                   cherrypy.session['host'], cherrypy.session['token'],
                                                                   "varray", "", "")
                # finalRequest["virtualArray"] = getValues(get_varrays_filename, 'get_varrays',viphost, token,
                # "varray","","")

            print(getArray)
            json_va_str = json.dumps(getArray)
            viprData["varray"] = json_va_str
            # return json.dumps(getArray)

            # get all block vpools GET /block/vpools
            """
                Get the vpools
            """
            get_vpool_filename = config['cache_directory'] + "/" + config[
                'vpools_fn'] + snHelper.replaceSpecialCharacters(cherrypy.session['host'])
            if (snHelper.checkIfFileExisits(get_vpool_filename)):
                get_response_jsontxt = snHelper.readFile(get_vpool_filename)

                finalRequest["virtualPool"], getPool = getValues2(get_response_jsontxt, "virtualpool", " - Block")
                # finalRequest["virtualPool"] = getValues2(get_response_jsontxt,"virtualpool", " - Block")
            else:
                finalRequest["virtualPool"], getPool = getValues(get_vpool_filename, 'get_blockVpools',
                                                                 cherrypy.session['host'], cherrypy.session['token'],
                                                                 "virtualpool", " - Block", "")
                # finalRequest["virtualPool"] = getValues(get_vpool_filename, 'get_blockVpools',viphost, token,
                # "virtualpool"," - Block","")
            json_vp_str = json.dumps(getPool)
            viprData["vpool"] = json_vp_str
            # return json.dumps(getPool)

            """
                Get the projects
            """
            # get all project GET get_project
            get_project_filename = config['cache_directory'] + "/" + config[
                'project_fn'] + snHelper.replaceSpecialCharacters(cherrypy.session['host'])
            print("marco")
            print(snHelper.checkIfFileExisits(get_project_filename))
            if (snHelper.checkIfFileExisits(get_project_filename)):
                get_response_jsontxt = snHelper.readFile(get_project_filename)

                finalRequest["project"], getPRJ = getValues2(get_response_jsontxt, "project", "")
                # finalRequest["project"] = getValues2(get_response_jsontxt,"project","")
            else:

                finalRequest["project"], getPRJ = getValues(get_project_filename, 'get_project',
                                                            cherrypy.session['host'], cherrypy.session['token'],
                                                            "project", "", cherrypy.session['tenantId'])
                # finalRequest["project"] = getValues(get_project_filename, 'get_project',viphost, token,"project",
                # "",tenantId)

            print(getPRJ)
            json_proj_str = json.dumps(getPRJ)
            viprData["project"] = json_proj_str
            # return json.dumps(getPRJ)
            print("hello")
            print(viprData)

            return json.dumps(viprData)
"""
    This class helps to POST the order to the vipr. hte payload is structured before sending to vipr for lun creation.
"""
class SendOrder(object):
    @cherrypy.expose()
    def index(self):
        request = cherrypy.request
        if request.method == 'POST':
            cl = cherrypy.request.headers['Content-Length']
            rawbody = cherrypy.request.body.read(int(cl)).decode("utf-8")
            ans = ((json.loads(rawbody)))

            targetCatalogServiceDescr = cherrypy.session['catalogServicesDict'][int(ans['catalog'])]
            print(cherrypy.session['catalogServicesDict'][1])

            items = targetCatalogServiceDescr["items"]

            print(ans['name'])

            finalRequest["virtualArray"] = finalRequest["virtualArray"][int(ans['virtualArray'])]["id"]
            finalRequest["virtualPool"] = finalRequest["virtualPool"][int(ans['virtualPool'])]["id"]
            finalRequest["project"] = finalRequest["project"][int(ans['project'])]["id"]
            # get the dependency list

            get_dependencyList_payload_str = {}
            referenceDict = {}
            for eachItem in targetCatalogServiceDescr["items"]:
                # get_dependencyList_req = config['getdependency_list']
                if ('field' in eachItem.keys()):
                    if (eachItem['field']['asset']):
                        pass

                    else:
                        if (eachItem['field']['type'] == "text"):
                            print(eachItem['field']['description'])
                            finalRequest[eachItem['field']['name']] = ans['name']
                        elif (not eachItem['field']['assetType']):
                            print(eachItem['field']['label'])
                            if "Volumes" in eachItem['field']['label']:
                                finalRequest[eachItem['field']['name']] = ans['numVols']
                            else:
                                finalRequest[eachItem['field']['name']] = ans['size']



                            #             #get catalog service id

            curr_cn = targetCatalogServiceDescr["title"].replace(" ", "")
            get_catalog_service_id_req = config['searchCatalog']
            get_catalog_service_id_req = get_catalog_service_id_req.replace("{catalogName}", curr_cn)

            get_catalog_service_id_response_jsontxt = viprConnection.get_request(cherrypy.session['host'],
                                                                                 cherrypy.session['token'],
                                                                                 get_catalog_service_id_req)
            catalogServicesIdList = get_catalog_service_id_response_jsontxt["resource"]

            for eachCatalogServiceId in catalogServicesIdList:
                if (eachCatalogServiceId["match"] == curr_cn):
                    # print(eachCatalogServiceDescr)
                    catalog_service_id = eachCatalogServiceId["id"]
                    break

            buildFinalRequest = {}
            buildFinalRequest["tenantId"] = cherrypy.session['tenantId']
            buildFinalRequest["catalog_service"] = catalog_service_id
            buildFinalRequest["parameters"] = []
            tempDict = {}
            for eachItem in finalRequest:
                tempDict = {}
                tempDict["label"] = eachItem
                tempDict["value"] = finalRequest[eachItem]
                buildFinalRequest["parameters"].append(tempDict)

            print('Placing the order..')

            buildFinalRequestPayload_str = buildFinalRequest

            postCatalogOrder_req = config['postCatalogOrder']

            postCatalogOrderResponse_jsontxt = viprConnection.post_request_json(cherrypy.session['host'],
                                                                                cherrypy.session['token'],
                                                                                postCatalogOrder_req,
                                                                                buildFinalRequestPayload_str)

            # print(postCatalogOrderResponse_jsontxt)
            print('Order is placed successfully.')


        # Logout Request
        logout_jsontext = viprConnection.logout(cherrypy.session['host'], cherrypy.session['token'])


class Root(object):
    def __init__(self):
        pass


if __name__ == '__main__':
    homeConfig = {
        '/':
            {
                'tools.staticdir.index': 'index.html',
                'tools.staticdir.dir': server_path + r'/static',
                'tools.sessions.on': True,
                'tools.staticdir.on': True
            }
    }
    restConfig = {
        '/':
            {
                'tools.sessions.on': True,
                'request.dispatch': cherrypy.dispatch.MethodDispatcher(),
                'tools.sessions.timeout': 300
            }
    }
    webapp = Root()
    webapp.dc = DataCenters()
    webapp.viprdata = GetViprData()

    webapp.submitOrder = SendOrder()
    cherrypy.tree.mount(webapp, '/', homeConfig)

    cherrypy.config.update({
        # 'server.socket_host': '0.0.0.0',
    'server.socket_port': 8080,
    })

    cherrypy.engine.start()
    cherrypy.engine.block()
