### VIPR-VolumeService


ViPR 2.3
Python 3.4

VolumeService is a shell written in python that uses ViPR’s API to create two volumes using two different virtual arrays. In order to use VolumeService, you have to follow the following steps:

### How to use
1.	Go to the folder where the source code is located and open VolumeService passing the username, password, and the ViPR instance.
2.	Once you hit “enter,” VolumeService will prompt you to enter; Volumen Name, Volume Size, Project Name, Host Name, Virtual Pool, Virtual Array 1 and Virtual Array 2. Once you enter that information and hit enter again, the process of creating the Volume starts.
3.	Once you can see that VolumeService prompts you for creating another volume, then the process of creating the volume has started.
4.	At this point we can check “My Orders” in the ViPR UI to make sure that everything is running properly.
5.	Once the processes are done, we can check that the volumes have been created.