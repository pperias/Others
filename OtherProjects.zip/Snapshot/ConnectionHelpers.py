"""
Copyright 2015 EMC Corporation
All Rights Reserved
EMC Confidential: Restricted Internal Distribution
81ff427ffd0a66013a8e07b7b967d6d6b5f06b1b.ViPR
"""
#!/usr/bin/python
# Version 1.1
# Debug library
import logging

# Print the REST response
def print_package(package):
    if hasattr(package, 'url') and hasattr(package, 'headers') and hasattr(package, 'text'):
        logging.debug("URL CALL:\n" + str(package.url))
        logging.debug("RESPONSE HEADERS:\n" + str(package.headers))
        logging.debug("RESPONSE BODY:\n" + str(package.text))
