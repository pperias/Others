import json
from ViPRConnection import ViPRConnection

import logging
import sys
import time
from SnapshotHelper import SnapshotHelper

"""
    CreateBlockSnapShot class helps to create block snapshots for the volume name/urn passed.
"""

class CreateBlockSnapShot(object):
    def __init__(self):
        FORMAT = "%(levelname)s:%(module)s:%(relativeCreated)dms:%(message)s"
        logging.basicConfig(filename='myapp.log', format=FORMAT, level=logging.DEBUG)
        logging.info("This script helps to create snapshots of a volume in ViPR")
        self.snapshotHelper = SnapshotHelper()
        arguments = self.snapshotHelper.parseArgumentsForCreateBlockSnapShot()
        self.viprConnection = ViPRConnection()
        self.config = self.snapshotHelper.readFile("config.json")
        self.main(arguments)

    """
        main function parses the arguments passed in the input and facilitates the Snapshot retention for the block volume passed
        myargs - input which are viphost - VIPT host, username - VIP username, password - VIP password and volume - block volume name
    """

    def main(self, myArgs):
        logging.info("ViPR Host is = " + myArgs.viphost)
        logging.info("Username = " + myArgs.username)
        logging.info("Password = " + myArgs.password)
        logging.info("Unique volume name or Volume (urn) id = " + myArgs.volume)

        # Get Token
        token = self.viprConnection.login(myArgs.viphost, myArgs.username, myArgs.password)

        volume_name, volume_urn = self.snapshotHelper.getVolumeDetails(myArgs.viphost, token, myArgs.volume,self.config, self.viprConnection)

        # Now having nailed down which volume we want to take snapshot, let's begin to take snapshots
        # Create Block Snapshots
        create_snapshot_req = self.config['create_blk_snpsht_api_request']
        create_snapshot_req = create_snapshot_req.replace("{id}", volume_urn)

        display_current_time = time.strftime("%Y_%m_%d_%H_%M")
        snapshot_name = volume_name + "_Snapshot_" + display_current_time

        create_snapshot_payload_str = self.config['create_blk_snpsht_payload']
        create_snapshot_payload_str = create_snapshot_payload_str.replace("snapshot_name_to_be_replaced", snapshot_name)

        create_snapshot_payload_json = json.loads(create_snapshot_payload_str)

        create_snapshot_response_jsontxt = self.viprConnection.post_request_json(myArgs.viphost, token,
                                                                                 create_snapshot_req,
                                                                                 create_snapshot_payload_json)

        if self.snapshotHelper.checkError(create_snapshot_response_jsontxt):
            logging.info("Error returned while invoking the API " + create_snapshot_req)
            logging.info("Payload " + create_snapshot_payload_json)
            exit(0)

        try:
            task_href_request = create_snapshot_response_jsontxt["task"][0]['link']['href']
        except:
            print("Task_href not found. Check the logs for more information. Quitting the script")
            exit(0)

        # Check if the task is success
        task_response_jsontxt = self.viprConnection.get_request(myArgs.viphost, token, task_href_request)

        # Get the task status.

        task_status = task_response_jsontxt[self.config["task_status_state_tag"]]

        if task_status == "ready":
            logging.info("Snapshot task completed successfully.")
        elif task_status == "error":
            logging.info("Snapshot task failed with the error message " + task_response_jsontxt["message"])

        # Logout Request
        logout_jsontext = self.viprConnection.logout(myArgs.viphost, token)


if __name__ == "__main__":
    CreateBlockSnapShot()
