"""
Copyright 2015 EMC Corporation
All Rights Reserved
EMC Confidential: Restricted Internal Distribution
81ff427ffd0a66013a8e07b7b967d6d6b5f06b1b.ViPR
"""
#!/usr/bin/python
#  ViPRConnection version 1.2
import json
import requests
import ConnectionHelpers
import urllib
import logging

# This class make the connection to ViPR
class ViPRConnection(object):
    session = requests.Session()
    server_ip = ""

    def login(self, vipr_host, user, password):
        self.server_ip = vipr_host
        if self.server_ip is not None:
            session = requests.Session()  # create connection session

            try:
                self.request = session.get("https://" + self.server_ip + ":4443/login", auth=(user, password), verify=False)
            except:
                print(str.format('{0} - Unable to connect...', self.server_ip))
                self.request = None
            finally:
                session.close()
            if hasattr(self, 'request'):  # Check the request was created
                ConnectionHelpers.print_package(self.request)
                if hasattr(self.request, 'headers') and 'x-sds-auth-token' in self.request.headers:  # Check the request was created
                    return self.request.headers['x-sds-auth-token']  # return the token
                else:
                    logging.debug(str.format("{0} - Can't get 'x-sds-auth-token' header", self.server_ip))
                    return None
            else:
                logging.debug(str.format("{0} - Can't get request information", self.server_ip))
                return None

    # Logout the user
    def logout(self, viprhost, token):
        logging.debug("token: " + token)
        self.request = self.session.get("https://" + viprhost + ':4443/logout', verify=False,
                                        headers={'x-sds-auth-token': token,
                                                 'Accept': 'application/json'})
        ConnectionHelpers.print_package(self.request)  # print out when in debug mode
        self.session.close()
        return json.loads(self.request.text)

    # Issue a GET request message to ViPR and returns the payload
    def get_request(self, viprhost, token, vipr_request):
        logging.debug("token: " + token)
        self.request = self.session.get("https://" + viprhost + ":4443" + vipr_request, verify=False,
                                        headers={'x-sds-auth-token': token,
                                                 'Accept': 'application/json'})
        ConnectionHelpers.print_package(self.request)  # print out when in debug mode
        self.session.close()
        return json.loads(self.request.text)

    # Issue a POST command to VIPR and return the payload
    def post_request_json(self, viprhost, token, vipr_request, payload):
        payload_json = json.dumps(payload)
        logging.debug("token: " + token)
        logging.debug("POST PAYLOAD: " + payload_json)
        self.session = requests.session()
        self.request = self.session.post("https://" + viprhost + ":4443" + vipr_request, verify=False, data=payload_json,
                                         headers={'x-sds-auth-token': token,
                                                  'Accept': 'application/json',
                                                  'Content-Type': 'application/json',
                                                  'Accept-Charset': 'utf-8'},
        )
        ConnectionHelpers.print_package(self.request)

        print(self.request.text)
        return json.loads(self.request.text)

    def post_request_urlencoded(self, viprhost, token, vipr_request, payload):
        encoded_payload = urllib.urlencode(payload)
        logging.debug("token: " + token)
        logging.debug("POST PAYLOAD: " + encoded_payload)
        self.session = requests.session()
        self.request = self.session.post("https://" + viprhost + ":4443" + vipr_request, verify=False, data=encoded_payload,
                                         headers={
                                             'Accept': 'application/json',
                                             'Content-Type': 'application/x-www-form-urlencoded',
                                             'Accept-Charset': 'utf-8',
                                             'X-SDS-AUTH-TOKEN': token
                                         },
        )
        ConnectionHelpers.print_package(self.request)
        print(self.request.text)
        return self.request.text
