import json

import logging
import time
import argparse
import os
import re

class SnapshotHelper(object):
    def __init__(self):
        # Seconds in each time period
        self.retention_period_dict = {'days': 86400, 'hours': 3600, 'minutes': 60, 'seconds': 1}

    """
        parseArgumentsForCreateSnapShot function parses the arguments passed in the input
        viphost - VIPT host
        username - VIP username
        password - VIP password
        volume - block volume name
    """

    def parseArgumentsForBlockSnapShot(self):
        parser = argparse.ArgumentParser()

        parser.add_argument('-vip', action='store', dest='viphost', help='ViPR VIP (hostname / IPV4)', required=True)
        parser.add_argument('-u', action='store', dest='username', help='Username to login to the ViPR', required=True)
        parser.add_argument('-p', action='store', dest='password', help='Password to login to the ViPR', required=True)
        parser.add_argument('-v', action='store', dest='volume', help='Unique volume name or Volume (urn) id',
                            required=True)
        return parser

    """
        parseArgumentsForCreateBlockSnapShot function parses the arguments passed in the input for CreateBlockSnapshot script
        viphost - VIPT host
        username - VIP username
        password - VIP password
        volume - block volume name
    """

    def parseArgumentsForCreateBlockSnapShot(self):
        parser = self.parseArgumentsForBlockSnapShot()
        arguments = parser.parse_args()
        return arguments

    """
        parseArgumentsForSnapshtRetention function parses the arguments passed in the input for SnapshotRetention script
        viphost - VIPT host
        username - VIP username
        password - VIP password
        volume - block volume name
        snapshot_retention - snapshot retention period
    """

    def parseArgumentsForSnapshtRetention(self):
        parser = self.parseArgumentsForBlockSnapShot()
        parser.add_argument('-r', action='store', dest='snapshot_retention', help='Snapshot retention period (in days)',
                            required=True)
        arguments = parser.parse_args()
        return arguments

    """
        getRetentionTime function gets the time difference in epoch time (from current time to the retentionPeriod passed in the input)
        retention_period_config - input retention period - Valid values are either 'days', 'hours', 'minutes', 'seconds'
        retention_period_value - the value passed in the input
        get_retention_time
        days - 24 * 60 * 60
        hours - 60*60
        min - 60
    """

    def getRetentionTime(self, retention_period_config, retention_period_value):
        reten_mult = 1
        if retention_period_config in self.retention_period_dict.keys():
            reten_mult = self.retention_period_dict.get(retention_period_config)
            display_current_time = time.strftime("%Y_%m_%d_%H_%M")
            logging.info("Current time is " + display_current_time)

            # return in milliseconds since vipr stores time in milli seconds
            return (int(time.time()) - int(retention_period_value) * reten_mult) * 1000
        else:
            return 0

    """
    get_parent_dir_location function gets the parent directory
    """

    def getParentDirLocation(self):
        src_dir = os.path.dirname(__file__)
        return src_dir

    """
    getFileLocation function getst he location of file
    fileName - filename to read
    """
    def getFileLocation(self, filename):
        return os.path.join(self.getParentDirLocation(), filename)

    """
    readFile function reads the json configuration file into memory
    fileName - filename to read
    """

    def readFile(self, fileName):
        try:
            fileHandle = open(self.getFileLocation(fileName), 'r')
            readFile_raw = fileHandle.read()
            logging.debug(fileName + ":\n" + readFile_raw)
            fileContentsList = json.loads(readFile_raw)
        except IOError:
            logging.error("Error: can\'t find file " + fileName + " or read data")
        else:
            fileHandle.close()
            return fileContentsList

    """
    checkError function reads the response and returns the error code, if any
    response - the response to investigate on
    """

    def checkError(self, response):
        try:
            errorcode = response[self.config['error_code_tag']]
            return True
        except:
            return False

    """
    getVolumeDetails function gets the volume details namely volume name and volume urn
    viphost - input viprhost
    token -  validated token
    volume - block volume urn / name
    config - config file handle
    viprConnection - ViprConnection handle
    """

    def getVolumeDetails(self, viphost, token, volume, config, viprConnection):
        volume_name = None
        volume_urn = None
        urn_regex = config['urn_regex']
        # The following regex is for urn
        urn = list(set(re.findall(urn_regex, volume)))
        volume_id_passed = False

        if len(urn) != 0:
            volume_id_passed = True
            logging.info("Volume (urn) id is passed. Invoking the GET /block/volumes/{id} API "
                         "to validate if the volume exists." + volume)
            search_volume_request = config['search_blk_vol_by_id_request']
            search_volume_response_root = config['search_blk_vol_response_by_name_root']
        else:
            logging.info("Volume name id is passed. Searching the volume by name " + volume)
            search_volume_request = config['search_blk_vol_by_name_request']
            search_volume_response_root = config['search_blk_vol_response_by_name_root']

        search_volume_request = search_volume_request + volume
        search_volume_response_jsontxt = viprConnection.get_request(viphost, token, search_volume_request)

        if self.checkError(search_volume_response_jsontxt):
            logging.info("Error returned while invoking the API " + search_volume_request)
            return volume_name, volume_urn

        search_volume_response_id_tag = config['search_blk_vol_response_id_tag']

        if volume_id_passed:
            self.checkError(search_volume_response_jsontxt)
            volume_name = search_volume_response_jsontxt["name"]
            volume_urn = volume
            # TODO:
            # check if the volume is active or inactive to make snapshots. Need to check how to find this. 'inactive'
            # tag?
        else:
            # get the volume URI if name is passed
            search_volume_response_root = config['search_blk_vol_response_by_name_root']
            search_volume_response_match_tag = config["search_blk_vol_response_match_tag"]

            num_volumes_returned = len(search_volume_response_jsontxt[search_volume_response_root])
            # verify that there are no more than one volume returned
            if num_volumes_returned > 1:
                logging.info("More than one volume returned for the name passed. "
                             "Pass the unique id (URN) instead of name from the following:")
                for i in range(num_volumes_returned):
                    logging.info("Volume URN(Id) for the name \"" +
                                 search_volume_response_jsontxt[search_volume_response_root][i][
                                     search_volume_response_match_tag] +
                                 "\" is " + search_volume_response_jsontxt[search_volume_response_root][i][
                                     search_volume_response_id_tag])
                else:
                    exit(0)
            elif num_volumes_returned == 1:
                # only one volume is returned. So take the colume id and use this for taking snaps
                volume_urn = search_volume_response_jsontxt[search_volume_response_root][num_volumes_returned - 1][
                    search_volume_response_id_tag]
                volume_name = volume
            else:
                logging.info(
                    "There are no volumes that exist with the name passed. Check the volume name and try again")

        return volume_name, volume_urn
