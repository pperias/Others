#!/usr/bin/python

import time
import os

scanning_minutes = 5

while True:
    print("Current time before running the script "+time.strftime("%Y_%m_%d_%H_%M"))
    os.system("python /home/vipr/Priya/CreateBlockSnapShot.py -vip lglw0108.lss.emc.com -u root -p ChangeMe1! -v XIO_Vol_demo2")
    print("Current time before running the script "+time.strftime("%Y_%m_%d_%H_%M"))
    print("sleeping")
    time.sleep(float(scanning_minutes) * 60)
