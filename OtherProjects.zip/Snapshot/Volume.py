__author__ = 'delats'


import ViPRConnection
import json
import sys
import time
import requests

flag = True  #boolean flag for the while loop
cmd = 0 #used to keep a track on the commands given

#global empty of the order to be sent.
orderCommon = {
        "tenantId": "",
        "parameters": [],
        "catalog_service": ""
}



if len(sys.argv) != 3:
    user = sys.argv[1]
    pswd = sys.argv[2]
    host = sys.argv[3]
    HTTPShost = "https://" + host
    viprInstance = ViPRConnection.ViPRConnection()
    token = viprInstance.login(HTTPShost, user, pswd)
else:
    print("Please, enter: <userName> <Password> <Hostname> ")
    sys.exit(0)

print("####### Welcome To VolumeService #######")


def check_space(lst_param):
    global cmd
    if '\\' in lst_param[cmd]:
        str = lst_param[cmd][:-1] + " " + lst_param[cmd + 1]
        cmd += 1
    else:
        str = lst_param[cmd]
    cmd += 1
    return str


def get_TenantID():
    global catalog_categoryID, tenantID
    catalog_category = json.loads(viprInstance.get_request(host, token, ":4443/catalog/categories"))
    catalog_categoryID = catalog_category['id']
    tenantID = catalog_category['tenant']['id']
    orderCommon['tenantId'] = tenantID


def get_CatalogServiceID():
    global catalog_serviceID
    catalog_services = json.loads(
        viprInstance.get_request(host, token, ":4443/catalog/services/search?name=CreateBlockVolumeforaHost"))
    catalog_serviceID = catalog_services['resource'][0]['id']
    orderCommon['catalog_service'] = catalog_serviceID


def replaceVA(orderCommon, vaID, volName, vaName):
    for p in orderCommon['parameters']:
        if p['label'] == "virtualArray":
            p['value'] = vaID
        if p['label'] == 'name':
            p['value'] = volName + "-" + vaName


while flag:
    print(" VolumeService: <volume name> <volume capacity> <project in ViPR> <hostname name in ViPR> <VP name in ViPR> <VA1 from ViPR> <VA2 from ViPR>")
    parameters = input("VolumeService: ")
    lst_param = parameters.split()

    if lst_param[0] == "help":
        print("Command Line Syntax:")
        print(" VolumeService: <volume name> <volume capacity> <project in ViPR> <hostname name in ViPR> <VP name in ViPR> <VA1 from ViPR> <VA2 from ViPR>")
    if lst_param[0] == "quit":
        flag = False
        print("####### Thank you for using VolumeService #######")

    elif len(lst_param) >= 6:
        #volume name
        volName = check_space(lst_param)

        #volume size
        volSize = check_space(lst_param)
        orderCommon['parameters'].append({"label": "size", "value": volSize})##size

        #get tenant id
        get_TenantID()

        #get Catalog Service
        get_CatalogServiceID()

        #project name
        prjName = check_space(lst_param)

        #get projectID
        projects = json.loads(viprInstance.get_request(host, token, ":4443/projects/search?name=" + prjName))

        #checking if the project name exist, if it does get its id, if it doesn't display error message.
        if len(projects['resource']) > 0:
            projectID = projects['resource'][0]['id']
            orderCommon['parameters'].append({"label": "project", "value": projectID})##
        else:
            cmd = 0
            print("Error: the project name was not found")
            continue

        #get hostname
        hostName = check_space(lst_param)
        hosts = json.loads(viprInstance.get_request(host, token, ":4443/compute/hosts/search?name="+hostName))

        #checking if the host name passed from the client exist, then get its id
        if len(hosts['resource']) > 0:
            hostID = hosts['resource'][0]['id']
            orderCommon['parameters'].append({"label": "host", "value": hostID})##virtual pool
        else:
            cmd = 0
            print("Error: the host name was not found")
            continue

        #get Virtualpool
        vpools = json.loads(viprInstance.get_request(host, token, ":4443/block/vpools"))

        VPool = check_space(lst_param)

        #retreive vpool_id using its name
        VPoolID = ""
        for vpool in vpools['virtualpool']:
            if vpool['name'] == VPool:
                VPoolID = vpool['id']

        #if virtual pool not found
        if not VPoolID:
            print("Error: Virtual Pool not found, please try again!")
            cmd = 0
            continue

        #Put pool in order
        orderCommon['parameters'].append({"label": "virtualPool", "value": VPoolID})##virtual pool

        #retreive virtaal array
        VAOne = check_space(lst_param)
        VATwo = check_space(lst_param)
        varrays = json.loads(viprInstance.get_request(host, token, ":4443/vdc/varrays"))

        #retreive VarraID using its name
        FirstVArrayID = ""
        SecondVArrayID = ""
        for varray in varrays['varray']:
            if varray['name'] == VAOne:
                FirstVArrayID = varray['id']
            elif varray['name'] == VATwo:
                SecondVArrayID = varray['id']

        #if virtual array not found
        if not FirstVArrayID:
            print("Error: The first Virtual Array was not found, please try again!")
            cmd = 0
            continue

        if not SecondVArrayID:
            print("Error: The Second Virtual Array was not found, please try again!")
            cmd = 0
            continue

        #Put Varray in order

        orderCommon['parameters'].append({"label": "virtualArray", "value": ""})##virtual array
        orderCommon['parameters'].append({"label": "name", "value": ""})##name


        #send orders
        replaceVA(orderCommon, FirstVArrayID,volName, VAOne)
        FirstOrder = json.loads(viprInstance.post_request(host, token, ":4443/catalog/orders", orderCommon))
        time.sleep(5)
        replaceVA(orderCommon, SecondVArrayID,volName, VATwo)
        secondOrder = json.loads(viprInstance.post_request(host, token, ":4443/catalog/orders", orderCommon))



        cmd = 0
    else:
        print("Command Line Syntax:")
        print("  VolumeService: <volume name> <volume capacity> <project in ViPR> <VP name in ViPR> <VA1 from ViPR> <VA2 from ViPR>")
