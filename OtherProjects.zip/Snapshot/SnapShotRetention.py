from ViPRConnection import ViPRConnection

import logging
import sys
from SnapshotHelper import SnapshotHelper
from operator import itemgetter

"""
    SnapShotRetention class helps to retain (and thus cleanup) the block snapshots for the volume name/urn passed.
"""

class SnapShotRetention(object):
    def __init__(self):
        self.snapshotHelper = SnapshotHelper()
        arguments = self.snapshotHelper.parseArgumentsForSnapshtRetention()
        FORMAT = "%(levelname)s:%(module)s:%(relativeCreated)dms:%(message)s"
        logging.basicConfig(stream=sys.stderr, format=FORMAT, level=logging.DEBUG)
        logging.info("This script helps to retain the  snapshots of a volume in ViPR")
        self.viprConnection = ViPRConnection()
        self.config = self.snapshotHelper.readFile("config.json")
        self.main(arguments)

    """
        main function parses the arguments passed in the input and facilitates the Snapshot retention for the block volume passed
        myargs - input which are viphost - VIPT host, username - VIP username, password - VIP password, volume - block volume name and snapshot_retention period
    """
    def main(self, myArgs):
        logging.info("ViPR Host is = " + myArgs.viphost)
        logging.info("Username = " + myArgs.username)
        logging.info("Password = " + myArgs.password)
        logging.info("Unique volume name or Volume (urn) id = " + myArgs.volume)
        logging.info("The block snapshot retention period is = " + myArgs.snapshot_retention)

        # Get Token
        token = self.viprConnection.login(myArgs.viphost, myArgs.username, myArgs.password)

        volume_name, volume_urn = self.snapshotHelper.getVolumeDetails(myArgs.viphost, token, myArgs.volume, self.config, self.viprConnection)

        # Now having nailed down which volume we want to take snapshot, let's begin to take snapshots
        # Create Block Snapshots
        get_block_snapshot_req = self.config['create_blk_snpsht_api_request']
        get_block_snapshot_req = get_block_snapshot_req.replace("{id}", volume_urn)

        get_block_snapshots_response_jsontxt = self.viprConnection.get_request(myArgs.viphost, token,
                                                                               get_block_snapshot_req)

        if self.snapshotHelper.checkError(get_block_snapshots_response_jsontxt):
            logging.info("Error returned while invoking the API " + get_block_snapshot_req)
            exit(0)

        # this gets the time <days> back in epoch time
        retention_time_until = self.snapshotHelper.getRetentionTime(self.config['retention_period'],
                                                                      myArgs.snapshot_retention)
        to_delete_snapshots_dict = {}

        try:
            # get the number of snapshots returned
            num_snapshots = len(get_block_snapshots_response_jsontxt["snapshot"])
            if num_snapshots < int(self.config['min_num_snapshots_to_retain']):
                logging.info(
                    "Number of snapshots is less than the configured snapshots in the config file. Hence the script "
                    "is exiting.")
                exit(0)
            for snapshot_itr in range(num_snapshots):
                get_blk_snapshot_href_request = get_block_snapshots_response_jsontxt["snapshot"][snapshot_itr]["link"][
                    "href"]
                get_blk_snapshot_detail_response_jsontxt = self.viprConnection.get_request(myArgs.viphost, token,
                                                                                           get_blk_snapshot_href_request)
                creation_time = get_blk_snapshot_detail_response_jsontxt["creation_time"]
                snapshot_id = get_blk_snapshot_detail_response_jsontxt["id"]
                if retention_time_until > int(creation_time):
                    logging.info("Retention time is more. Adding the snapshot to delete list")
                    to_delete_snapshots_dict[snapshot_id] = creation_time

            # we have got all the snapshots, now we should delete only the oldest snaps which satisfy the retention
            # period
            # and also we should be careful not to delete all the snaps. ie., min_num_snapshots_to_retain should be
            # satisfied as well

            to_delete_snapshots_sorted_by_time_list = sorted(to_delete_snapshots_dict.items(), key=itemgetter(1))

            while num_snapshots > int(self.config['min_num_snapshots_to_retain']):
                delete_snapshot_req = self.config['delete_blk_snpsht_api_request']
                # get the snap id from the sorted list
                delete_snapshot_req = delete_snapshot_req.replace("{id}", to_delete_snapshots_sorted_by_time_list[0][0])
                delete_snapshotresponse_jsontxt = self.viprConnection.post_request_json(myArgs.viphost, token,
                                                                                        delete_snapshot_req, "")
                if self.snapshotHelper.checkError(delete_snapshotresponse_jsontxt):
                    logging.info("Error returned while invoking the API " + delete_snapshot_req)
                else:
                    num_snapshots -= 1

        except Exception as e:
            print(
                "Exception occured while deleting block snapshots. " + e.message, e.args +
                "Check the logs for more information. Quitting the script.")
            exit(0)

        # Logout Request
        logout_jsontext = self.viprConnection.logout(myArgs.viphost, token)

if __name__ == "__main__":
    SnapShotRetention()
