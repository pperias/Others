#!/usr/bin/python
import json

import logging
import shutil
import time
import argparse
import os
import re
import sys


class SNHelper(object):
    def __init__(self):
        pass


    """
    get_parent_dir_location function gets the parent directory
    """

    def getParentDirLocation(self):
        src_dir = os.path.dirname(__file__)
        return src_dir

    """
    getFileLocation function getst he location of file
    fileName - filename to read
    """
    def getFileLocation(self, filename):
        return os.path.join(self.getParentDirLocation(), filename)

    """
    readFile function reads the json configuration file into memory
    fileName - filename to read
    """

    def readFile(self, fileName):
        try:
            fileHandle = open(self.getFileLocation(fileName), 'r')
            readFile_raw = fileHandle.read()
            logging.debug(fileName + ":\n" + readFile_raw)
            fileContentsList = json.loads(readFile_raw)
        except IOError:
            logging.error("Error: can\'t find file " + fileName + " or read data")
        else:
            fileHandle.close()
            return fileContentsList

    """
    checkError function reads the response and returns the error code, if any
    response - the response to investigate on
    """

    def checkError(self, response):
        try:
            errorcode = response[self.config['error_code_tag']]
            return True
        except:
            return False

    def printValues(self, response_jsontxt, rootTag, printText, keyName, ValueName):
        if(len(response_jsontxt) > 0):
                printMethodList = response_jsontxt[rootTag]
                if(not printMethodList):
                    return
                print(printText + ". Select one from the list")
                i = 1
                printMethodDict = {}
                for eachItemInList in printMethodList:
                    itemName = eachItemInList[ValueName]
                    itemId = eachItemInList[keyName]
                    printMethodDict[i] = {"id":itemId,"name":itemName}
                    print(str(i) + ". " + itemName)
                    i = i + 1

                print("Pick a number from the above")
                answer=sys.stdin.readline()
                answer = answer.strip()
                if(answer.isdigit()):
                    #print(printMethodDict[int(answer)])
                    return printMethodDict[int(answer)]
    def get_parent_dir_location(self):
        src_dir = os.path.dirname(__file__)
        return src_dir

    def get_dir_file_location(self, filename):
        return os.path.join(self.get_parent_dir_location(), filename)

    def createCacheDirectory(self):
        cache_directory = "cache"
        if not os.path.isdir(cache_directory):
            os.makedirs(self.get_dir_file_location(cache_directory))
        else:
            logging.debug(str.format("Directory '{0}' found", cache_directory))

    def checkIfFileExisits(self, filename):
        if(os.path.isfile(filename)):
            return True
        else:
            return False


    def writeJasonDataToFile(self, data, outFileName):

        with open(outFileName, 'w') as outfile:
            json.dump(data, outfile)

    def replaceSpecialCharacters(self, input):
        replacedString = re.sub(r'[^a-zA-Z0-9_-]',r'_',input)
        return replacedString

    def clearCache(self):
        self.lmLogger.debug("Clearing cache directory")
        #shutil.rmtree(self.data_directory)
        for folder in os.listdir("cache"):
            folder_path = os.path.join("cache", folder)
            try:
                if os.path.isfile(folder_path):
                    os.unlink(folder_path)
                elif os.path.isdir(folder_path):
                    shutil.rmtree(folder_path)
            except Exception as e:
                print(e)



