#!/usr/bin/python

__author__ = 'periap'


import sys

# import bin
# from dbDocBin import CommonUtil
# sys.path.insert(0, "C:/Python34/lib/site-packages/dbdoctor-1.0-py3.4.egg/dbDocBin/.")
from dbDocBin import DBUtil
path = "C:\Projects\ServiceNow\dump_files"

dbUtilObj = DBUtil.DBUtil(path)



urn = dbUtilObj.get_urn_for_label('10.247.144.25','host')
print(urn)


if(not urn):
    myurn = dbUtilObj.get_label('10.247.144.25')
    print("above is empty "+myurn)


print("My result" )
print( dbUtilObj.get_label('VMAX-VA'))



print(dbUtilObj.get_label_for_urn('urn:storageos:Host:f604a577-0247-45ee-885a-0263c3df9ce0:vdc1'))

