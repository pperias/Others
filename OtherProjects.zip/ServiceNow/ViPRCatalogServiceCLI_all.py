#!/usr/bin/python
import json
from ViPRConnection import ViPRConnection
from SNHelper import SNHelper


import logging
import sys
import time

class ViPRCatalogServiceCLI_2(object):
    def __init__(self):
        FORMAT = "%(levelname)s:%(module)s:%(relativeCreated)dms:%(message)s"
        logging.basicConfig(filename='myapp.log', format=FORMAT, level=logging.DEBUG)
        logging.info("This script helps to create snapshots of a volume in ViPR")
        
        self.snHelper = SNHelper()
        # arguments = self.snHelper.parseArgumentsForCreateBlockSnapShot()
        arguments = []
        self.viprConnection = ViPRConnection()
        self.config = self.snHelper.readFile("config.json")
        self.snHelper.createCacheDirectory()
        self.main()

    """
        main function parses the arguments passed in the input and facilitates the Snapshot retention for the block volume passed
        myargs - input which are viphost - VIPT host, username - VIP username, password - VIP password and volume - block volume name
    """

    def readFile(self, fileName):
        try:
            fileHandle = open(self.getFileLocation(fileName), 'r')
            readFile_raw = fileHandle.read()
            logging.debug(fileName + ":\n" + readFile_raw)
            fileContentsList = json.loads(readFile_raw)
        except IOError:
            logging.error("Error: can\'t find file " + fileName + " or read data")
        else:
            fileHandle.close()
            return fileContentsList

    def getValues(self, writeFilename, config_key, viphost, token, root_tag, desc, changeValue):
        get_varrays_req = self.config[config_key]
        if(changeValue):
            get_varrays_req = get_varrays_req.replace("{id}", changeValue)
        response_jsontxt = self.viprConnection.get_request(viphost, token, get_varrays_req)
        self.snHelper.writeJasonDataToFile(response_jsontxt, writeFilename)
        return self.getValues2(response_jsontxt, root_tag,desc)

    def getValues2(self,response_jsontxt, root_tag, desc):
        varraysList = response_jsontxt[root_tag]
        varraysDict={}
        i = 1
        for eachvarray in varraysList:
            varraysDict[i] = eachvarray
            print(str(i) + ". " + eachvarray["name"])
            i = i + 1

        print("Pick a number from the above " + root_tag + " " + desc)
        answer = sys.stdin.readline()
        answer = answer.strip()

        targetVarray = varraysDict[int(answer)]
        return targetVarray["id"]


    def main(self):
        dcList = self.config['viprs']
        i =1

        dcDict = {}

        for eachItem in dcList:
            for dc_key, dc_value in eachItem.items():
                pass
            print(str(i) + ". " + dc_key)
            dcDict[i] = dc_value
            i = i + 1


        print("Enter which DC you would like to do provisioning")
        answer=sys.stdin.readline()
        answer = answer.strip()

        viphost = dcDict[int(answer)]["host"]
        username = dcDict[int(answer)]["username"]
        password = dcDict[int(answer)]["password"]
        logging.info("ViPR Host is = " + viphost)
        # logging.info("Username = " + username)
        # logging.info("Password = " + password)

        # Get Token
        token = self.viprConnection.login(viphost, username, password)

        #Get Tenant
        # For the demo go with provider tenant
        get_tenant_req = self.config['get_tenant']
        getTenant_response_jsontxt = self.viprConnection.get_request(viphost, token, get_tenant_req)
        tenantId = getTenant_response_jsontxt["id"]

        # print(tenantId)


        finalRequest = {}
        # get service descriptor GET /catalog/service-descriptors
        get_catalog_service_descriptors_filename = self.config['cache_directory'] + "/" + self.config['catalog_service_descriptors_fn']+self.snHelper.replaceSpecialCharacters(viphost)
        if(self.snHelper.checkIfFileExisits(get_catalog_service_descriptors_filename)):
            get_catalog_service_descriptors_response_jsontxt = self.snHelper.readFile(get_catalog_service_descriptors_filename)
        else:

            get_catalog_service_descriptors_req = self.config['get_catalog_service_descriptors']
            get_catalog_service_descriptors_response_jsontxt = self.viprConnection.get_request(viphost, token, get_catalog_service_descriptors_req)

            #get_catalog_service_descriptors_response_jsontxt = self.snHelper.readFile("serviceDesc_test.json")
            self.snHelper.writeJasonDataToFile(get_catalog_service_descriptors_response_jsontxt, get_catalog_service_descriptors_filename)

        catalogServicesDescriptorList = get_catalog_service_descriptors_response_jsontxt["service_descriptor"]
        catalogServicesDict={}
        i = 1
        for eachCatalogServiceDescr in catalogServicesDescriptorList:
            catalogServicesDict[i] = eachCatalogServiceDescr
            print(str(i) + ". " + eachCatalogServiceDescr["title"])
            i = i + 1

        print("Pick a number from the above Services")
        answer = sys.stdin.readline()
        answer = answer.strip()

        targetCatalogServiceDescr = catalogServicesDict[int(answer)]

        # get all varrays GET vdc/varrays
        get_varrays_filename = self.config['cache_directory'] + "/" + self.config['varrays_fn'] + self.snHelper.replaceSpecialCharacters(viphost)
        if(self.snHelper.checkIfFileExisits(get_varrays_filename)):
            get_response_jsontxt = self.snHelper.readFile(get_varrays_filename)

            finalRequest["virtualArray"] = self.getValues2(get_response_jsontxt,"varray","")
        else:
            finalRequest["virtualArray"] = self.getValues(get_varrays_filename, 'get_varrays',viphost, token,"varray","","")

        # get all block vpools GET /block/vpools
        get_vpool_filename = self.config['cache_directory'] + "/" + self.config['vpools_fn']+self.snHelper.replaceSpecialCharacters(viphost)
        if(self.snHelper.checkIfFileExisits(get_vpool_filename)):
            get_response_jsontxt = self.snHelper.readFile(get_vpool_filename)
            finalRequest["virtualPool"] = self.getValues2(get_response_jsontxt,"virtualpool", " - Block")
        else:
            finalRequest["virtualPool"] = self.getValues(get_vpool_filename, 'get_blockVpools',viphost, token,"virtualpool"," - Block","")

        # get all project GET get_project
        get_project_filename = self.config['cache_directory'] + "/" + self.config['project_fn']+self.snHelper.replaceSpecialCharacters(viphost)
        if(self.snHelper.checkIfFileExisits(get_project_filename)):
            get_response_jsontxt = self.snHelper.readFile(get_project_filename)
            finalRequest["project"] = self.getValues2(get_response_jsontxt,"project","")
        else:
            finalRequest["project"] = self.getValues(get_project_filename, 'get_project',viphost, token,"project","",tenantId)



        items = targetCatalogServiceDescr["items"]
        # #get the dependency list for this category
        # dependencyList = []
        # for eachItem in targetCatalogServiceDescr["items"]:
        #     myKey = eachItem.keys()
        #     if('field' in eachItem.keys()):
        #         if(eachItem['field']['asset']):
        #             dependencyList.append(eachItem['field']['assetType'])
        #     elif('group' in eachItem.keys()):
        #         for eachGroupItem in eachItem['group']["items"]:
        #             if('field' in eachGroupItem.keys()):
        #                 if(eachGroupItem['field']['asset']):
        #                     dependencyList.append(eachGroupItem['field']['assetType'])



        #get the dependency list

        get_dependencyList_payload_str = {}
        referenceDict = {}
        for eachItem in targetCatalogServiceDescr["items"]:
            # get_dependencyList_req = self.config['getdependency_list']
            if('field' in eachItem.keys()):
                if(eachItem['field']['asset'] ):
                    pass
                    # am commenting the code in if because we do not want to build this list dynamically. customer do not want to come back and forth
                    # to vipr for info. so we get the values such as varray, block vpool and project before hand.
                    # commenting this code and assuming that this is only for create volumes
                    # this might have been already available for the 2so exiting the if loop
                    # get_dependencyList_req = get_dependencyList_req.replace("{assetType}", eachItem['field']['assetType'])
                    #
                    # get_dependencyList_payload_str["availableAssetTypes"] = dependencyList
                    # get_dependencyList_payload_str["tenantId"] = tenantId
                    #
                    # get_dependencyListresponse_jsontxt = self.viprConnection.post_request_json(viphost, token,
                    #                                                                         get_dependencyList_req, get_dependencyList_payload_str)
                    # result = get_dependencyListresponse_jsontxt["assetDependencies"]
                    #
                    # makeRequest_payload = {}
                    # makeRequest = self.config['assetRequest']
                    # makeRequest = makeRequest.replace("{assetType}", eachItem['field']['assetType'])
                    #
                    # makeRequest_payload["tenantId"] = tenantId
                    # if not result:
                    #     pass
                    # else:
                    #     #add dependency
                    #     availableAssetsDict = {}
                    #     for eachAssetDep in result:
                    #         if(test_serviceCategory == "Remove Block Volumes"):
                    #             referenceDict["vipr.deletionType"] = "FULL"
                    #
                    #         availableAssetsDict[eachAssetDep] = referenceDict[eachAssetDep]
                    #     makeRequest_payload["availableAssets"] = availableAssetsDict
                    #
                    #
                    # makeResponse_jsontxt = self.viprConnection.post_request_json(viphost, token,
                    #                                                                         makeRequest, makeRequest_payload)
                    # returnDict = self.snHelper.printValues(makeResponse_jsontxt, "options", "The options available are as follows.", "key", "value")
                    #
                    # if(returnDict):
                    #     referenceDict[eachItem['field']['assetType']] = returnDict["id"]
                    #     finalRequest[eachItem['field']['name']] = returnDict["id"]
                    # if(len(makeRequest_jsontxt["options"] > 0)):
                    #     print("The options available are as follows. Select one from the list")
                    #     i = 1
                    #     for eachOption in makeRequest_jsontxt["options"]:
                    #         print()

                else:
                    if(eachItem['field']['type'] == "text" ):
                        print(eachItem['field']['description'])
                    elif(not eachItem['field']['assetType']):
                        print(eachItem['field']['label'])
                    answer=sys.stdin.readline()
                    answer = answer.strip()
                    finalRequest[eachItem['field']['name']] = answer


        #get catalog service id

        curr_cn = targetCatalogServiceDescr["title"].replace(" ","")
        get_catalog_service_id_req = self.config['searchCatalog']
        get_catalog_service_id_req = get_catalog_service_id_req.replace("{catalogName}", curr_cn)

        get_catalog_service_id_response_jsontxt = self.viprConnection.get_request(viphost, token, get_catalog_service_id_req)
        catalogServicesIdList = get_catalog_service_id_response_jsontxt["resource"]

        for eachCatalogServiceId in catalogServicesIdList:
            if(eachCatalogServiceId["match"] == curr_cn):
                #print(eachCatalogServiceDescr)
                catalog_service_id = eachCatalogServiceId["id"]
                break





        buildFinalRequest = {}
        buildFinalRequest["tenantId"] = tenantId
        buildFinalRequest["catalog_service"] = catalog_service_id
        buildFinalRequest["parameters"] = []
        tempDict={}
        for eachItem in finalRequest:
            tempDict={}
            tempDict["label"] = eachItem
            tempDict["value"] = finalRequest[eachItem]
            buildFinalRequest["parameters"].append(tempDict)


        #print(buildFinalRequest)

        print('\n\n\nDo you want to place the order with the above selected values... Press Y to continue... Any other key to quit: ')
        answer=sys.stdin.readline()

        if(answer.strip().upper()  == 'Y'):

            print('Placing the order..')


            buildFinalRequestPayload_str = buildFinalRequest

            postCatalogOrder_req = self.config['postCatalogOrder']

            postCatalogOrderResponse_jsontxt = self.viprConnection.post_request_json(viphost, token, postCatalogOrder_req, buildFinalRequestPayload_str)

            #print(postCatalogOrderResponse_jsontxt)
            print('Order is placed successfully.')
        else:
            print('Quiting without placing the order..')







        # Logout Request
        logout_jsontext = self.viprConnection.logout(viphost, token)


if __name__ == "__main__":
    ViPRCatalogServiceCLI_2()

