__author__ = 'jcolon'


class HostManager(object):
    @staticmethod
    def parse_host_data(data):
        host_list = []
        # print("Data to process" + data)
        for row in data[1:]:
            print(row)
            cols = str(row).split(',')
            # host = Host(cols[0], cols[1], cols[2], cols[3], cols[4], cols[5], cols[6], cols[7])

            host = {'name': cols[0].replace("b'", ""),
                    'host_name': cols[1],
                    'type': cols[2],
                    'use_ssl': True,
                    'port_number': cols[4],
                    'user_name': cols[5],
                    'password': cols[6],
                    'discoverable': False}
            host['discoverable']

            # Override the default USE_SSL and use the config parameter
            if cols[3].upper() == "FALSE":
                host['use_ssl'] = False

            # Override the default DISCOVERABLE and use the config parameter
            if cols[7].replace("\\r", "").replace("\\n", "").replace("'",
                                                                     "").upper() == 'TRUE':
                host['discoverable'] = True

            host_list.append(host)

        return host_list