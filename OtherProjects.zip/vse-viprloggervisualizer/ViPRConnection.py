import ConnectionHelpers
import json

__author__ = 'jcolon'

import requests

from xml.dom import minidom


class ViPRConnection(object):
    session = requests.Session()
    server_url = ""
    # __token = "OK"

    def login(self, server_url, user, password):
        self.server_url = server_url
        if self.server_url is not None:
            self.session = requests.Session()
            self.request = self.session.get(self.server_url + ":4443/login", auth=(user, password), verify=False)
            ConnectionHelpers.print_package(self.request)
            return self.request.headers['x-sds-auth-token']

    #
    # @property
    # def token(self):
    # return self.__token
    #
    # @token.setter
    # def token(self, token):
    # self.__token = token

    def get_user_roles(self):
        self.request = self.session.get(self.server_url + "/user/whoami", verify=False,
                                        headers={'x-sds-auth-token': self.token})
        ConnectionHelpers.print_package(self.request)
        xml_doc = minidom.parseString(self.request.text)
        roles = xml_doc.getElementsByTagName("vdc_role")
        rlist = []
        for role in roles:
            rlist.append(role.firstChild.wholeText)
        print("Roles: " + str(rlist))
        return rlist

    def get_request(self, viprhost, token, vipr_request):
        self.request = self.session.get("https://" + viprhost + vipr_request, verify=False,
                                        headers={'x-sds-auth-token': token,
                                                 'Accept': 'application/json'})
        ConnectionHelpers.print_package(self.request)
        return self.request.text

    def post_request(self, viprhost, token, vipr_request, payload):
        payload_json = json.dumps(payload)
        print("POST PAYLOAD: " + payload_json)
        self.request = self.session.post("https://" + viprhost + vipr_request, verify=False, data=payload_json,
                                         headers={'x-sds-auth-token': token,
                                                  'Accept': 'application/json',
                                                  'Content-Type': 'application/json',
                                                  'Accept-Charset': 'utf-8'},
                                         )
        ConnectionHelpers.print_package(self.request)
        print(self.request.text)
        return self.request.text
