#!/usr/bin/python
import viprlogger
from viprlogger import ViPRLogManager

import cherrypy
import tempfile
import json
import os

from HostManager import HostManager

localDir = os.path.dirname(__file__)
absDir = os.path.join(os.getcwd(), localDir)

class NamedPart(cherrypy._cpreqbody.Part):

  def make_file(self):
    return tempfile.NamedTemporaryFile()

cherrypy._cpreqbody.Entity.part_class = NamedPart

class Root(object):
    @cherrypy.expose()
    def index(self):
        print(cherrypy.server.thread_pool_max)
        print(cherrypy.server.thread_pool)
        return "hello world"

    @cherrypy.config(**{'response.timeout': 3600})  # default is 300s
    def fileupload(self, inputFile, orderInfo):
        print("inside the fileupload function")
        assert isinstance(inputFile, cherrypy._cpreqbody.Part)

        # Double copy with standard ``cherrypy._cpreqbody.Part``
        import shutil
        from viprlogger import ViPRLogManager
        baseDir = "C:\CustomSolutions\logManager\outputAnalysis"
        #baseDir = "/data/workspace/input"


        ViPRLogManager_handle = ViPRLogManager.ViPRLogManager()


        analysisDir = ViPRLogManager_handle.getAnalysisDirId(baseDir)

        destination = os.path.join(analysisDir, inputFile.filename)

        #os.link(inputFile.file.name, destination)

        with open(destination, 'wb') as f:
            shutil.copyfileobj(inputFile.file, f)


        # ViPRLogManager_handle.startAnalysis(analysisDir, os.path.normpath(destination), orderInfo)



        return os.path.basename(os.path.normpath(analysisDir))


    index.exposed = True
    fileupload.exposed = True

# starts here


binPath = os.path.dirname(os.path.abspath(__file__))
print("Bin Path: " + binPath)
# URL routes

apiConfig = {'/':
                 {'tools.sessions.on': True,
                  }}

cherrypy.tree.mount(Root(), '/api', config=apiConfig)


# Server configuration
cherrypy.config.update({
    'server.socket_host': '0.0.0.0',
    'server.socket_port': 443,
    'server.ssl_module': 'builtin',
    'server.ssl_certificate': 'vviprcert.pem',
    'server.ssl_private_key': 'vviprkey.pem',
    'tools.encode.encoding': "utf-8",
    'tools.json_in.on': True,
    'tools.json_in.force': False,
    # remove any limit on the request body size; cherrypy's default is 100MB
    'server.max_request_body_size' : 0,
    # increase server socket timeout to 60s; cherrypy's defult is 10s
    'server.socket_timeout' : 60,
    'server.thread_pool' : 10
})

# Server listening stats/block
cherrypy.engine.start()
cherrypy.engine.block()
