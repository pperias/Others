__author__ = 'jcolon'


def print_package(package):
    print("URL CALL:\n" + package.url)
    print("RESPONSE HEADERS:\n", package.headers)
    print("RESPONSE BODY:\n", package.text)
