import os
import sqlite3
import time

__author__ = 'jcolon'

DB_STRING = "performance.db"


class DBManager(object):

    def setup(self):
        with sqlite3.connect(DB_STRING) as con:
            con.execute(
                "CREATE TABLE Performance (node_id VARCHAR(255), timestamp double, metric_type, valie_float double)")

    @staticmethod
    def cleanup():
        with sqlite3.connect(DB_STRING) as con:
            con.execute("DROP TABLE Performance")

    @staticmethod
    def get_metric(node_id):
        with sqlite3.connect(DB_STRING) as con:
            con.execute("SELECT (node_id, timestamp, metric_type, value_float) FROM Performance WHERE node_id=?",
                        [node_id])
            return con.fetchall()

    @staticmethod
    def add_metric(node_id, metric_type, value_float):
        timestamp = time.time()
        with sqlite3.connect(DB_STRING) as con:
            con.execute("INSERT INTO Performance (node_id, timestamp, metric_type, value_float) VALUES (?, ?,?,?)",
                        [node_id], [timestamp], [metric_type], [value_float])

    @staticmethod
    def add_node():
        return

    @staticmethod
    def get_nodes():
        return

    @staticmethod
    def remove_nodes():
        return

    if not os.path.isfile(DB_STRING):
        print("Creating DB Schema")
        setup()


